function varargout = guitar(varargin)
% GUITAR MATLAB code for guitar.fig
%      GUITAR, by itself, creates a new GUITAR or raises the existing
%      singleton*.
%
%      H = GUITAR returns the handle to a new GUITAR or the handle to
%      the existing singleton*.
%
%      GUITAR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUITAR.M with the given input arguments.
%
%      GUITAR('Property','Value',...) creates a new GUITAR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before guitar_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to guitar_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help guitar

% Last Modified by GUIDE v2.5 15-Apr-2017 17:08:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @guitar_OpeningFcn, ...
                   'gui_OutputFcn',  @guitar_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before guitar is made visible.
function guitar_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to guitar (see VARARGIN)

% Choose default command line output for guitar
handles.output = hObject;

% create an axes that spans the whole gui
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('guitar.png');imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');

global c4 fs fc4 f1 f2 f3 f4 f5 f6 n1 n2 n3 n4 n5 n6 mute6 mute5 au
[c4, fs] = audioread('guitarSamples\Alesis-Fusion-Nylon-String-Guitar-C4.wav');
fc4 = 261.6;
mute6 = 0;
mute5 = 0;
f6 = 82; %OPEN E
f5 = 110; %OPEN A
f4 = 147; %OPEN D
f3 = 196; %OPEN G
f2 = 247; %OPEN B
f1 = 329; %OPEN E
n6 = 1;
n5 = 1;
n4 = 1;
n3 = 1;
n2 = 1;
n1 = 1;
au = audiorecorder(44100, 16, 2);

set(handles.audio,'visible','off')

% Update handles structure
guidata(hObject, handles);

function musicVisualizer(y, Fs)

% Common Variables
player = audioplayer(y,Fs);
y = y(:,2)*10;
lenY = length(y);
lengthSong = lenY/Fs;
timeSkip = 350/44100;

time = 0;

play(player);
myt = tic;
while time<lengthSong
    tic
    time = toc(myt);
    
    % waveformRange is for the wave form ranges, which is updated on every loop run
    % If at the beginning of song, just grabbing the first interval
    if (time < timeSkip)
        time = timeSkip+.001;
    end
    waveformRange = [ceil((time-timeSkip)*44100) ceil((time+timeSkip)*44100)];
    
    % Making sure to not have a limit beyond song length
    if (waveformRange(2) >= lenY)
        waveformRange(2)= lenY;
    end
    waveformRange = waveformRange(1):waveformRange(end);
    
    % If the input range is empty, we're past the end of the song
    if isempty(waveformRange)
        break;
    end
    
    % First plot, waveform
    plot(y(waveformRange)/max(abs(y(waveformRange))),'c') %plotting the data with limits -1 to 1
    ylim([-1,1])
    set(gca,'xtick',[],'ytick',[])
    set(gca,'Color',[0 0 0])
    %axis off
    time = toc(myt);
    pause(.01);
end

% UIWAIT makes guitar wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = guitar_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in 6th string.
function s6_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f6 n6 mute6
MulFactor = f6/fc4;
NewSampleRate = fs * MulFactor;
if mute6 == 0
    sound(c4(1:length(c4)/n6,:), NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
end

% --- Executes on button press in 5th string.
function s5_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f5 n5 mute5
MulFactor = f5/fc4;
NewSampleRate = fs * MulFactor;
if mute5 == 0
    sound(c4(1:length(c4)/n5,:), NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
end


% --- Executes on button press in 4th string.
function s4_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f4 n4 
MulFactor = f4/fc4;
NewSampleRate = fs * MulFactor;
sound(c4(1:length(c4)/n4,:), NewSampleRate)
musicVisualizer(c4, NewSampleRate)


% --- Executes on button press in 3rd string.
function s3_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f3 n3
MulFactor = f3/fc4;
NewSampleRate = fs * MulFactor;
sound(c4(1:length(c4)/n3,:), NewSampleRate)
musicVisualizer(c4, NewSampleRate)


% --- Executes on button press in 2nd string.
function s2_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f2 n2 
MulFactor = f2/fc4;
NewSampleRate = fs * MulFactor;
sound(c4(1:length(c4)/n2,:), NewSampleRate)
musicVisualizer(c4, NewSampleRate)


% --- Executes on button press in 1st string.
function s1_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f1 n1
MulFactor = f1/fc4;
NewSampleRate = fs * MulFactor;
sound(c4(1:length(c4)/n1,:), NewSampleRate)
musicVisualizer(c4, NewSampleRate)


% --- Executes on button press in down strum.
function dstrum_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f6 f5 f4 f3 f2 f1 n6 n5 n4 n3 n2 n1 mute6 mute5
if mute6 == 0
    sound(c4(1:length(c4)/n6,:), fs*f6/fc4)
end
if mute5 == 0
    sound(c4(1:length(c4)/n5,:), fs*f5/fc4)
end
sound(c4(1:length(c4)/n4,:), fs*f4/fc4)
sound(c4(1:length(c4)/n3,:), fs*f3/fc4)
sound(c4(1:length(c4)/n2,:), fs*f2/fc4)
sound(c4(1:length(c4)/n1,:), fs*f1/fc4)
musicVisualizer(c4(1:length(c4)/n6,:), fs*f6/fc4)


% --- Executes on button press in up strum.
function ustrum_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f6 f5 f4 f3 f2 f1 n6 n5 n4 n3 n2 n1 mute6 mute5
sound(c4(1:length(c4)/n1,:), fs*f1/fc4)
sound(c4(1:length(c4)/n2,:), fs*f2/fc4)
sound(c4(1:length(c4)/n3,:), fs*f3/fc4)
sound(c4(1:length(c4)/n4,:), fs*f4/fc4)
if mute5 == 0
    sound(c4(1:length(c4)/n5,:), fs*f5/fc4)
end
if mute6 == 0
    sound(c4(1:length(c4)/n6,:), fs*f6/fc4)
end
musicVisualizer(c4(1:length(c4)/n6,:), fs*f6/fc4)


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f1 f2 f3 f4 f5 f6 mute6 mute5
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y
set(handles.lbl_x, 'string', ['x loc:' num2str(x)]); % update text for x loc
set(handles.lbl_y, 'string', ['y loc:' num2str(y)]); % update text for y loc
set(handles.lbl_x,'visible','off')
set(handles.lbl_y,'visible','off')

if ( x >= 280  && x <= 360 ) && ( y >= 276  && y <= 279 )
    MulFactor = f6/fc4;
    NewSampleRate = fs * MulFactor;
    if mute6 == 0
        sound(c4, NewSampleRate)
        musicVisualizer(c4, NewSampleRate)
    end
elseif ( x >= 280  && x <= 360 ) && ( y >= 267  && y <= 269 )
    MulFactor = f5/fc4;
    NewSampleRate = fs * MulFactor;
    if mute5 == 0
        sound(c4, NewSampleRate)
        musicVisualizer(c4, NewSampleRate)
    end
elseif ( x >= 280  && x <= 360 ) && ( y >= 258  && y <= 261 )
    MulFactor = f4/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
elseif ( x >= 280  && x <= 360 ) && ( y >= 249  && y <= 252 )
    MulFactor = f3/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
elseif ( x >= 280  && x <= 360 ) && ( y >= 240  && y <= 243 )
    MulFactor = f2/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
elseif ( x >= 280  && x <= 360 ) && ( y >= 231  && y <= 234 )
    MulFactor = f1/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
end


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global c4 fs fc4 f1 f2 f3 f4 f5 f6 mute6 mute5
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y

if ( x >= 280  && x <= 360 ) && ( y >= 276  && y <= 279 )
    MulFactor = f6/fc4;
    NewSampleRate = fs * MulFactor;
    if mute6 == 0
        sound(c4, NewSampleRate)
        musicVisualizer(c4, NewSampleRate)
    end
elseif ( x >= 280  && x <= 360 ) && ( y >= 267  && y <= 269 )
    MulFactor = f5/fc4;
    NewSampleRate = fs * MulFactor;
    if mute5 == 0
        sound(c4, NewSampleRate)
        musicVisualizer(c4, NewSampleRate)
    end
elseif ( x >= 280  && x <= 360 ) && ( y >= 258  && y <= 261 )
    MulFactor = f4/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
elseif ( x >= 280  && x <= 360 ) && ( y >= 249  && y <= 252 )
    MulFactor = f3/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
elseif ( x >= 280  && x <= 360 ) && ( y >= 240  && y <= 243 )
    MulFactor = f2/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
elseif ( x >= 280  && x <= 360 ) && ( y >= 231  && y <= 234 )
    MulFactor = f1/fc4;
    NewSampleRate = fs * MulFactor;
    sound(c4, NewSampleRate)
    musicVisualizer(c4, NewSampleRate)
end


% --- Executes on selection change in mode.
function mode_Callback(hObject, eventdata, handles)
% hObject    handle to mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns mode contents as cell array
%        contents{get(hObject,'Value')} returns selected item from mode
global c4 fs
contents = cellstr(get(handles.mode,'String'));
popChoice = contents(get(handles.mode,'Value'));
if strcmp(popChoice,'Nylon String Acoustic Guitar')
	[c4, fs] = audioread('guitarSamples\Alesis-Fusion-Nylon-String-Guitar-C4.wav');
elseif strcmp(popChoice,'Steel String Acoustic Guitar')
	[c4, fs] = audioread('guitarSamples\Alesis-Fusion-Steel-String-Guitar-C4.wav');
elseif strcmp(popChoice,'Jazz Guitar')
	[c4, fs] = audioread('guitarSamples\Roland-SC-88-Jazz-Guitar-C4.wav');
elseif strcmp(popChoice,'Electric Guitar 1')
	[c4, fs] = audioread('guitarSamples\Korg-N1R-TubeCrunch-C4.wav');
elseif strcmp(popChoice,'Electric Guitar 2')
	[c4, fs] = audioread('guitarSamples\Yamaha-EX5-Strat-4-Way-C4.wav');
else
    [c4, fs] = audioread('guitarSamples\Yamaha-TG500-GT-Strt1-C4.wav');
end


% --- Executes during object creation, after setting all properties.
function mode_CreateFcn(hObject, eventdata, handles)
% hObject    handle to mode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on key press with focus on figure1 or any of its controls.
function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
eventdata.Key;
switch eventdata.Key
    case 'numpad6'
        s6_Callback(handles,[],handles);
    case 'numpad5'
        s5_Callback(handles,[],handles);
    case 'numpad4'
        s4_Callback(handles,[],handles);
    case 'numpad3'
        s3_Callback(handles,[],handles);
    case 'numpad2'
        s2_Callback(handles,[],handles);
    case 'numpad1'
        s1_Callback(handles,[],handles);    
    case 'space'
        dstrum_Callback(handles,[],handles);
    case 'return'
        ustrum_Callback(handles,[],handles);
end


% --- Executes on selection change in chords.
function chords_Callback(hObject, eventdata, handles)
% hObject    handle to chords (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns chords contents as cell array
%        contents{get(hObject,'Value')} returns selected item from chords
global f1 f2 f3 f4 f5 f6 mute6 mute5
contents = cellstr(get(handles.chords,'String'));
popChoice = contents(get(handles.chords,'Value'));
if strcmp(popChoice,'Open')
    mute6 = 0;
    mute5 = 0;
	f6 = 82; %OPEN E
    f5 = 110; %OPEN A
    f4 = 147; %OPEN D
    f3 = 196; %OPEN G
    f2 = 247; %OPEN B
    f1 = 329; %OPEN E
elseif strcmp(popChoice,'A Major')
	mute6 = 1;
    mute5 = 0;
    f5 = 110; %OPEN A
    f4 = 165; %2F D
    f3 = 220; %2F G
    f2 = 277; %2F B
    f1 = 329; %OPEN E
elseif strcmp(popChoice,'A Minor')
	mute6 = 1;
    mute5 = 0;
    f5 = 110; %OPEN A
    f4 = 165; %2F D
    f3 = 220; %2F G
    f2 = 262; %1F B
    f1 = 329; %OPEN E 
elseif strcmp(popChoice,'B Major')
	mute6 = 1;
    mute5 = 0;
    f5 = 123; %2F A
    f4 = 185; %4F D
    f3 = 247; %4F G
    f2 = 311; %4F B
    f1 = 370; %2F E
elseif strcmp(popChoice,'B Minor')
	mute6 = 1;
    mute5 = 0;
    f5 = 123; %2F A
    f4 = 185; %4F D
    f3 = 247; %4F G
    f2 = 294; %3F B
    f1 = 370; %2F E
elseif strcmp(popChoice,'C Major')
	mute6 = 0;
    mute5 = 0;
    f6 = 98; %3F E
    f5 = 131; %3F A
    f4 = 165; %2F D
    f3 = 196; %OPEN G
    f2 = 262; %1F B
    f1 = 329; %OPEN E
elseif strcmp(popChoice,'C Minor')
	mute6 = 0;
    mute5 = 0;
    f6 = 98; %3F E
    f5 = 131; %3F A
    f4 = 196; %5F D
    f3 = 262; %5F G
    f2 = 311; %4F B
    f1 = 392; %3F E
elseif strcmp(popChoice,'D Major')
	mute6 = 1;
    mute5 = 1;
    f4 = 165; %OPEN D
    f3 = 220; %2F G
    f2 = 294; %3F B
    f1 = 370; %2F E
elseif strcmp(popChoice,'D Minor')
	mute6 = 1;
    mute5 = 1;
    f4 = 165; %OPEN D
    f3 = 220; %2F G
    f2 = 294; %3F B
    f1 = 349; %1F E
elseif strcmp(popChoice,'E Major')
    mute6 = 0;
    mute5 = 0;
	f6 = 82; %OPEN E
    f5 = 123; %2F A
    f4 = 165; %2F D
    f3 = 208; %1F G
    f2 = 247; %OPEN B
    f1 = 329; %OPEN E
elseif strcmp(popChoice,'E Minor')
    mute6 = 0;
    mute5 = 0;
	f6 = 82; %OPEN E
    f5 = 123; %2F A
    f4 = 165; %2F D
    f3 = 196; %OPEN G
    f2 = 247; %OPEN B
    f1 = 329; %OPEN E
elseif strcmp(popChoice,'F Major')
    mute6 = 0;
    mute5 = 0;
	f6 = 87; %1F E
    f5 = 131; %3F A
    f4 = 175; %3F D
    f3 = 220; %2F G
    f2 = 262; %1F B
    f1 = 349; %1F E
elseif strcmp(popChoice,'F Minor')
    mute6 = 0;
    mute5 = 0;
	f6 = 87; %1F E
    f5 = 131; %3F A
    f4 = 175; %3F D
    f3 = 208; %1F G
    f2 = 262; %1F B
    f1 = 349; %1F E
elseif strcmp(popChoice,'G Major')
    mute6 = 0;
    mute5 = 0;
	f6 = 98; %3F E
    f5 = 123; %2F A
    f4 = 147; %OPEN D
    f3 = 196; %OPEN G
    f2 = 247; %OPEN B
    f1 = 392; %3F E
elseif strcmp(popChoice,'G Minor')
    mute6 = 0;
    mute5 = 0;
	f6 = 98; %3F E
    f5 = 117; %1F A
    f4 = 147; %OPEN D
    f3 = 196; %OPEN G
    f2 = 294; %3F B
    f1 = 392; %3F E
end


% --- Executes during object creation, after setting all properties.
function chords_CreateFcn(hObject, eventdata, handles)
% hObject    handle to chords (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in record.
function record_Callback(hObject, eventdata, handles)
% hObject    handle to record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au
record(au, 44100)


% --- Executes on button press in play.
function play_Callback(hObject, eventdata, handles)
% hObject    handle to play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au
y = getaudiodata(au);
plot(handles.audio,y)
set(gca,'xtick',[],'ytick',[])
sound(y, 44100)

% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au
stop(au)
y = getaudiodata(au);
plot(handles.audio,y)
set(gca,'xtick',[],'ytick',[])


function filename_Callback(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filename as text
%        str2double(get(hObject,'String')) returns contents of filename as a double


% --- Executes during object creation, after setting all properties.
function filename_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au
filenm = get(handles.filename,'String');
y = getaudiodata(au);
audiowrite(strcat(filenm,'.wav'),y,44100)
