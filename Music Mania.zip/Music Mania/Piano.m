function varargout = Piano(varargin)
% PIANO MATLAB code for Piano.fig
%      PIANO, by itself, creates a new PIANO or raises the existing
%      singleton*.
%
%      H = PIANO returns the handle to a new PIANO or the handle to
%      the existing singleton*.
%
%      PIANO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PIANO.M with the given input arguments.
%
%      PIANO('Property','Value',...) creates a new PIANO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Piano_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Piano_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Piano

% Last Modified by GUIDE v2.5 16-Apr-2017 20:16:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Piano_OpeningFcn, ...
                   'gui_OutputFcn',  @Piano_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Piano is made visible.
function Piano_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Piano (see VARARGIN)

% Choose default command line output for Piano
handles.output = hObject;

[handles.c4, handles.fc4]=audioread('39187__jobro__piano-ff-040.wav');
[handles.d4, handles.fd4]=audioread('39189__jobro__piano-ff-042.wav');
[handles.e4, handles.fe4]=audioread('39191__jobro__piano-ff-044.wav');
[handles.f4, handles.ff4]=audioread('39193__jobro__piano-ff-045.wav');
[handles.g4, handles.fg4]=audioread('39195__jobro__piano-ff-047.wav');
[handles.a4, handles.fa4]=audioread('39197__jobro__piano-ff-049.wav');
[handles.b4, handles.fb4]=audioread('39199__jobro__piano-ff-051.wav');
[handles.c5, handles.fc5]=audioread('39200__jobro__piano-ff-052.wav');
[handles.d5, handles.fd5]=audioread('39202__jobro__piano-ff-054.wav');
[handles.e5, handles.fe5]=audioread('39204__jobro__piano-ff-056.wav');
[handles.f5, handles.ff5]=audioread('39205__jobro__piano-ff-057.wav');
[handles.g5, handles.fg5]=audioread('39207__jobro__piano-ff-059.wav');
[handles.a5, handles.fa5]=audioread('39209__jobro__piano-ff-061.wav');
[handles.b5, handles.fb5]=audioread('39211__jobro__piano-ff-063.wav');
[handles.cs4, handles.fcs4]=audioread('39188__jobro__piano-ff-041.wav');
[handles.ds4, handles.fds4]=audioread('39190__jobro__piano-ff-043.wav');
[handles.fs4, handles.ffs4]=audioread('39194__jobro__piano-ff-046.wav');
[handles.gs4, handles.fgs4]=audioread('39196__jobro__piano-ff-048.wav');
[handles.as4, handles.fas4]=audioread('39198__jobro__piano-ff-050.wav');
[handles.cs5, handles.fcs5]=audioread('39201__jobro__piano-ff-053.wav');
[handles.ds5, handles.fds5]=audioread('39203__jobro__piano-ff-055.wav');
[handles.fs5, handles.ffs5]=audioread('39206__jobro__piano-ff-058.wav');
[handles.gs5, handles.fgs5]=audioread('39208__jobro__piano-ff-060.wav');
[handles.as5, handles.fas5]=audioread('39210__jobro__piano-ff-062.wav');

global au;
au=audiorecorder;
% Update handles structure
guidata(hObject, handles);

function musicVisualizer(y, Fs)

% Common Variables
player = audioplayer(y,Fs);
y = y(:,2)*10;
lenY = length(y);
lengthSong = lenY/Fs;
timeSkip = 150/44100;

time = 0;

play(player);
myt = tic;
while time<lengthSong
    tic
    time = toc(myt);
    
    % waveformRange is for the wave form ranges, which is updated on every loop run
    % If at the beginning of song, just grabbing the first interval
    if (time < timeSkip)
        time = timeSkip+.001;
    end
    waveformRange = [ceil((time-timeSkip)*44100) ceil((time+timeSkip)*44100)];
    
    % Making sure to not have a limit beyond song length
    if (waveformRange(2) >= lenY)
        waveformRange(2)= lenY;
    end
    waveformRange = waveformRange(1):waveformRange(end);
    
    % If the input range is empty, we're past the end of the song
    if isempty(waveformRange)
        break;
    end
    
    % First plot, waveform
    plot(y(waveformRange)/max(abs(y(waveformRange))),'c') %plotting the data with limits -1 to 1
    ylim([-1,1])
    set(gca,'xtick',[],'ytick',[])
    set(gca,'Color',[0.15 0.15 0.15])
    %axis off
    time = toc(myt);
    pause(.01);
end


% UIWAIT makes Piano wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Piano_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on button press in c4.
function c4_Callback(hObject, eventdata, handles)
% hObject    handle to c4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%global handles.c4;
sound(handles.c4,handles.fc4);
musicVisualizer(handles.c4, handles.fc4)


% --- Executes on button press in d4.
function d4_Callback(hObject, eventdata, handles)
% hObject    handle to d4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.d4,handles.fd4);
musicVisualizer(handles.d4, handles.fd4)


% --- Executes on button press in e4.
function e4_Callback(hObject, eventdata, handles)
% hObject    handle to e4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.e4,handles.fe4);
musicVisualizer(handles.e4, handles.fe4)


% --- Executes on button press in f4.
function f4_Callback(hObject, eventdata, handles)
% hObject    handle to f4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.f4,handles.ff4);
musicVisualizer(handles.f4, handles.ff4)


% --- Executes on button press in g4.
function g4_Callback(hObject, eventdata, handles)
% hObject    handle to g4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.g4,handles.fg4);
musicVisualizer(handles.g4, handles.fg4)


% --- Executes on button press in a4.
function a4_Callback(hObject, eventdata, handles)
% hObject    handle to a4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.a4,handles.fa4);
musicVisualizer(handles.a4, handles.fa4)


% --- Executes on button press in b4.
function b4_Callback(hObject, eventdata, handles)
% hObject    handle to b4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.b4,handles.fb4);
musicVisualizer(handles.b4, handles.fb4)


% --- Executes on button press in c5.
function c5_Callback(hObject, eventdata, handles)
% hObject    handle to c5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.c5,handles.fc5);
musicVisualizer(handles.c5, handles.fc5)


% --- Executes on button press in d5.
function d5_Callback(hObject, eventdata, handles)
% hObject    handle to d5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.d5,handles.fd5);
musicVisualizer(handles.d5, handles.fd5)


% --- Executes on button press in e5.
function e5_Callback(hObject, eventdata, handles)
% hObject    handle to e5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.e5,handles.fe5);
musicVisualizer(handles.e5, handles.fe5)


% --- Executes on button press in f5.
function f5_Callback(hObject, eventdata, handles)
% hObject    handle to f5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.f5,handles.ff5);
musicVisualizer(handles.f5, handles.ff5)


% --- Executes on button press in g5.
function g5_Callback(hObject, eventdata, handles)
% hObject    handle to g5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.g5,handles.fg5);
musicVisualizer(handles.g5, handles.fg5)


% --- Executes on button press in a5.
function a5_Callback(hObject, eventdata, handles)
% hObject    handle to a5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.a5,handles.fa5);
musicVisualizer(handles.a5, handles.fa5)


% --- Executes on button press in b5.
function b5_Callback(hObject, eventdata, handles)
% hObject    handle to b5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.b5,handles.fb5);
musicVisualizer(handles.b5, handles.fb5)


% --- Executes on button press in cs4.
function cs4_Callback(hObject, eventdata, handles)
% hObject    handle to cs4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.cs4,handles.fcs4);
musicVisualizer(handles.cs4, handles.fcs4)


% --- Executes on button press in ds4.
function ds4_Callback(hObject, eventdata, handles)
% hObject    handle to ds4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.ds4,handles.fds4);
musicVisualizer(handles.ds4, handles.fds4)


% --- Executes on button press in fs4.
function fs4_Callback(hObject, eventdata, handles)
% hObject    handle to fs4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.fs4,handles.ffs4);
musicVisualizer(handles.fs4, handles.ffs4)


% --- Executes on button press in gs4.
function gs4_Callback(hObject, eventdata, handles)
% hObject    handle to gs4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.gs4,handles.fgs4);
musicVisualizer(handles.gs4, handles.fgs4)


% --- Executes on button press in as4.
function as4_Callback(hObject, eventdata, handles)
% hObject    handle to as4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.as4,handles.fas4);
musicVisualizer(handles.as4, handles.fas4)


% --- Executes on button press in cs5.
function cs5_Callback(hObject, eventdata, handles)
% hObject    handle to cs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.cs5,handles.fcs5);
musicVisualizer(handles.cs5, handles.fcs5)


% --- Executes on button press in ds5.
function ds5_Callback(hObject, eventdata, handles)
% hObject    handle to ds5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.ds5,handles.fds5);
musicVisualizer(handles.ds5, handles.fds5)


% --- Executes on button press in fs5.
function fs5_Callback(hObject, eventdata, handles)
% hObject    handle to fs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.fs5,handles.ffs5);
musicVisualizer(handles.fs5, handles.ffs5)


% --- Executes on button press in gs5.
function gs5_Callback(hObject, eventdata, handles)
% hObject    handle to gs5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.gs5,handles.fgs5);
musicVisualizer(handles.gs5, handles.fgs5)


% --- Executes on button press in as5.
function as5_Callback(hObject, eventdata, handles)
% hObject    handle to as5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sound(handles.as5,handles.fas5);
musicVisualizer(handles.as5, handles.fas5)


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonUpFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on key press with focus on figure1 or any of its controls.
function figure1_WindowKeyPressFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  structure with the following fields (see MATLAB.UI.FIGURE)
%	Key: name of the key that was pressed, in lower case
%	Character: character interpretation of the key(s) that was pressed
%	Modifier: name(s) of the modifier key(s) (i.e., control, shift) pressed
% handles    structure with handles and user data (see GUIDATA)
eventdata.Key;
switch eventdata.Key
    case 'q'
        c4_Callback(handles.c4, [] , handles);
    case 'w'
        d4_Callback(handles.d4, [] , handles);
    case 'e'
        e4_Callback(handles.e4, [] , handles);
    case 'r'
        f4_Callback(handles.f4, [] , handles);
    case 't'
        g4_Callback(handles.g4, [] , handles);
    case 'y'
        a4_Callback(handles.a4, [] , handles);
    case 'u'
        b4_Callback(handles.b4, [] , handles);
    case 'i'
        c5_Callback(handles.c5, [] , handles);
    case 'o'
        d5_Callback(handles.d5, [] , handles);
    case 'p'
        e5_Callback(handles.e5, [] , handles);
    case 'leftbracket'
        f5_Callback(handles.f5, [] , handles);
    case 'rightbracket'
        g5_Callback(handles.g5, [] , handles);
    case 'backslash'
        a5_Callback(handles.a5, [] , handles);
    case 'numpad7'
        b5_Callback(handles.b5, [] , handles);
    case '1'
        cs4_Callback(handles.cs4, [] , handles);
    case '2'
        ds4_Callback(handles.cs4, [] , handles);
    case '3'
        fs4_Callback(handles.cs4, [] , handles);
    case '4'
        gs4_Callback(handles.cs4, [] , handles);
    case '5'
        as4_Callback(handles.cs4, [] , handles);
    case '6'
        cs5_Callback(handles.cs4, [] , handles);
    case '7'
        ds5_Callback(handles.cs4, [] , handles);
    case '8'
        fs5_Callback(handles.cs4, [] , handles);
    case '9'
        gs5_Callback(handles.cs4, [] , handles);
    case '0'
        as5_Callback(handles.cs4, [] , handles);
end


% --- Executes on button press in record.
function record_Callback(hObject, eventdata, handles)
% hObject    handle to record (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au;
record(au,handles.fc4);


% --- Executes on button press in play.
function play_Callback(hObject, eventdata, handles)
% hObject    handle to play (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au;
y=getaudiodata(au);
plot(handles.audio,y);
set(gca,'xtick',[],'ytick',[])
sound(y,handles.fc4);


% --- Executes on button press in stop.
function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au;
stop(au);
y=getaudiodata(au);
plot(handles.audio,y);
set(gca,'xtick',[],'ytick',[])


function filename_Callback(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of filename as text
%        str2double(get(hObject,'String')) returns contents of filename as a double


% --- Executes during object creation, after setting all properties.
function filename_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filename (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in save.
function save_Callback(hObject, eventdata, handles)
% hObject    handle to save (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global au;
filenm=get(handles.filename,'String');
y=getaudiodata(au);
audiowrite(strcat(filenm,'.wav'),y,handles.fc4);