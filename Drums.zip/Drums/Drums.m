function varargout = Drums(varargin)
% DRUMS MATLAB code for Drums.fig
%      DRUMS, by itself, creates a new DRUMS or raises the existing
%      singleton*.
%
%      H = DRUMS returns the handle to a new DRUMS or the handle to
%      the existing singleton*.
%
%      DRUMS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DRUMS.M with the given input arguments.
%
%      DRUMS('Property','Value',...) creates a new DRUMS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Drums_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Drums_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Drums

% Last Modified by GUIDE v2.5 15-Apr-2017 00:45:15

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Drums_OpeningFcn, ...
                   'gui_OutputFcn',  @Drums_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Drums is made visible.
function Drums_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Drums (see VARARGIN)


% Choose default command line output for Drums
handles.output = hObject;
handles.cc1 = audioread('drumsamples\Crash-Cymbal-1.wav');
handles.hh = audioread('drumsamples\Hi-Hat.wav');
handles.sd = audioread('drumsamples\Snare-Drum.wav');
handles.st = audioread('drumsamples\Small-Tom.wav');
handles.mt = audioread('drumsamples\Mid-Tom.wav');
handles.bd = audioread('drumsamples\Bass-Drum.wav');
handles.ft1 = audioread('drumsamples\Floor-Tom-1.wav');
handles.ft2 = audioread('drumsamples\Floor-Tom-2.wav');
handles.cc2 = audioread('drumsamples\Crash-Cymbal-2.wav');
handles.rc = audioread('drumsamples\Ride-Cymbal.wav');

% create an axes that spans the whole gui
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('drums.jpg');imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');

set(handles.axes1,'visible','off')

% Update handles structure
guidata(hObject, handles);

function musicVisualizer(y, Fs)

% Common Variables
player = audioplayer(y,Fs);
y = y(:,2)*10;
lenY = length(y);
lengthSong = lenY/Fs;
timeSkip = 350/44100;

time = 0;

play(player);
myt = tic;
while time<lengthSong
    tic
    time = toc(myt);
    
    % waveformRange is for the wave form ranges, which is updated on every loop run
    % If at the beginning of song, just grabbing the first interval
    if (time < timeSkip)
        time = timeSkip+.001;
    end
    waveformRange = [ceil((time-timeSkip)*44100) ceil((time+timeSkip)*44100)];
    
    % Making sure to not have a limit beyond song length
    if (waveformRange(2) >= lenY)
        waveformRange(2)= lenY;
    end
    waveformRange = waveformRange(1):waveformRange(end);
    
    % If the input range is empty, we're past the end of the song
    if isempty(waveformRange)
        break;
    end
    
    % First plot, waveform
    plot(y(waveformRange)/max(abs(y(waveformRange))),'c') %plotting the data with limits -1 to 1
    ylim([-1,1])
    set(gca,'xtick',[],'ytick',[])
    set(gca,'Color',[0.1 0.1 0.1])
    %axis off
    time = toc(myt);
    pause(.01);
end

% UIWAIT makes Drums wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Drums_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y

crash_cymbal1 = [124 266];
hihat = [78 155];
snare_drum = [182 127];
small_tom = [221 255];
medium_tom = [401 294];
crash_cymbal2 = [615 175];
ride_cymbal = [556 284];
floor_tom2 = [530 120];
floor_tom1 = [478 210];
%bass_drum = [692 449];

dcrash_cymbal1 = sqrt(((c(1,2)-crash_cymbal1(1,2))^2)+((c(1,1)-crash_cymbal1(1,1))^2));
dhihat = sqrt(((c(1,2)-hihat(1,2))^2)+((c(1,1)-hihat(1,1))^2));
dsnare_drum = sqrt(((c(1,2)-snare_drum(1,2))^2)+((c(1,1)-snare_drum(1,1))^2));
dsmall_tom = sqrt(((c(1,2)-small_tom(1,2))^2)+((c(1,1)-small_tom(1,1))^2));
dmedium_tom = sqrt(((c(1,2)-medium_tom(1,2))^2)+((c(1,1)-medium_tom(1,1))^2));
dcrash_cymbal2 = sqrt(((c(1,2)-crash_cymbal2(1,2))^2)+((c(1,1)-crash_cymbal2(1,1))^2));
dride_cymbal = sqrt(((c(1,2)-ride_cymbal(1,2))^2)+((c(1,1)-ride_cymbal(1,1))^2));
dfloor_tom2 = sqrt(((c(1,2)-floor_tom2(1,2))^2)+((c(1,1)-floor_tom2(1,1))^2));
dfloor_tom1 = sqrt(((c(1,2)-floor_tom1(1,2))^2)+((c(1,1)-floor_tom1(1,1))^2));
%dbass_drum = sqrt(((c(1,2)-bass_drum(1,2))^2)+((c(1,1)-bass_drum(1,1))^2));

if dcrash_cymbal1 <= 68
    sound(handles.cc1, 44100)
    musicVisualizer(handles.cc1, 44100)
elseif dhihat <= 50
    sound(handles.hh, 44100)
    musicVisualizer(handles.hh, 44100)
elseif dsnare_drum <= 59
    sound(handles.sd, 44100)
    musicVisualizer(handles.sd, 44100)
elseif dsmall_tom <= 52
    sound(handles.st, 44100)
    musicVisualizer(handles.st, 44100)
elseif dmedium_tom <= 50
    sound(handles.mt, 44100)    
    musicVisualizer(handles.mt, 44100)
elseif ( ( 99*x + 25*y >= 30608 ) && ( 97*x + 22*y <= 45528 ) && ( 33*x - 157*y <= -17408 ) && ( 31*x - 160*y >= -35058 ) ) || (x>=325 && x <=360 && y>=120 && y<=165)
    sound(handles.bd, 44100)  
    musicVisualizer(handles.bd, 44100)
elseif dcrash_cymbal2 <= 52
    sound(handles.cc2, 44100)
    musicVisualizer(handles.cc2, 44100)
elseif dride_cymbal <= 75
    sound(handles.rc, 44100)
    musicVisualizer(handles.rc, 44100)
elseif dfloor_tom2 <= 68
    sound(handles.ft2, 44100)
    musicVisualizer(handles.ft2, 44100)
elseif dfloor_tom1 <= 51
    sound(handles.ft1, 44100)  
    musicVisualizer(handles.ft1, 44100)
end


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y
set(handles.lbl_x, 'string', ['x loc:' num2str(x)]); % update text for x loc
set(handles.lbl_y, 'string', ['y loc:' num2str(y)]); % update text for y loc
set(handles.lbl_x,'visible','off')
set(handles.lbl_y,'visible','off')

crash_cymbal1 = [124 266];
hihat = [78 155];
snare_drum = [182 127];
small_tom = [221 255];
medium_tom = [401 294];
crash_cymbal2 = [615 175];
ride_cymbal = [556 284];
floor_tom2 = [530 120];
floor_tom1 = [478 210];
%bass_drum = [692 449];

dcrash_cymbal1 = sqrt(((c(1,2)-crash_cymbal1(1,2))^2)+((c(1,1)-crash_cymbal1(1,1))^2));
dhihat = sqrt(((c(1,2)-hihat(1,2))^2)+((c(1,1)-hihat(1,1))^2));
dsnare_drum = sqrt(((c(1,2)-snare_drum(1,2))^2)+((c(1,1)-snare_drum(1,1))^2));
dsmall_tom = sqrt(((c(1,2)-small_tom(1,2))^2)+((c(1,1)-small_tom(1,1))^2));
dmedium_tom = sqrt(((c(1,2)-medium_tom(1,2))^2)+((c(1,1)-medium_tom(1,1))^2));
dcrash_cymbal2 = sqrt(((c(1,2)-crash_cymbal2(1,2))^2)+((c(1,1)-crash_cymbal2(1,1))^2));
dride_cymbal = sqrt(((c(1,2)-ride_cymbal(1,2))^2)+((c(1,1)-ride_cymbal(1,1))^2));
dfloor_tom2 = sqrt(((c(1,2)-floor_tom2(1,2))^2)+((c(1,1)-floor_tom2(1,1))^2));
dfloor_tom1 = sqrt(((c(1,2)-floor_tom1(1,2))^2)+((c(1,1)-floor_tom1(1,1))^2));
%dbass_drum = sqrt(((c(1,2)-bass_drum(1,2))^2)+((c(1,1)-bass_drum(1,1))^2));

if dcrash_cymbal1 <= 68
    set(gcf, 'Pointer','hand')
elseif dhihat <= 50
    set(gcf, 'Pointer','hand')
elseif dsnare_drum <= 59
    set(gcf, 'Pointer','hand')
elseif dsmall_tom <= 52
    set(gcf, 'Pointer','hand')
elseif dmedium_tom <= 50
    set(gcf, 'Pointer','hand')
elseif ( ( 99*x + 25*y >= 30608 ) && ( 97*x + 22*y <= 45528 ) && ( 33*x - 157*y <= -17408 ) && ( 31*x - 160*y >= -35058 ) ) || (x>=325 && x <=360 && y>=120 && y<=165)
    set(gcf, 'Pointer','hand')
elseif dcrash_cymbal2 <= 52
    set(gcf, 'Pointer','hand')
elseif dride_cymbal <= 75
    set(gcf, 'Pointer','hand')
elseif dfloor_tom2 <= 68
    set(gcf, 'Pointer','hand')
elseif dfloor_tom1 <= 51
    set(gcf, 'Pointer','hand')
else
    set(gcf, 'Pointer','arrow')
end
