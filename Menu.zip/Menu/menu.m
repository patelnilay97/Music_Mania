function varargout = menu(varargin)
% MENU MATLAB code for menu.fig
%      MENU, by itself, creates a new MENU or raises the existing
%      singleton*.
%
%      H = MENU returns the handle to a new MENU or the handle to
%      the existing singleton*.
%
%      MENU('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MENU.M with the given input arguments.
%
%      MENU('Property','Value',...) creates a new MENU or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before menu_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to menu_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help menu

% Last Modified by GUIDE v2.5 12-Apr-2017 19:15:39

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @menu_OpeningFcn, ...
                   'gui_OutputFcn',  @menu_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before menu is made visible.
function menu_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to menu (see VARARGIN)


% Choose default command line output for menu
handles.output = hObject;

% create an axes that spans the whole gui
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('menu.png');imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');

i = imread('piano_icon.png');
handles.input=im2double(i);
axes(handles.piano_axes);
a = get(gca,'ButtonDownFcn');
h = imagesc(handles.input,'Parent',gca);
set(h,'HitTest','on');
set(gca,'ButtonDownFcn',a);
set(h,'ButtonDownFcn',a);
set(handles.piano_axes,'visible','off');

i = imread('drum_icon.png');
handles.input=im2double(i);
axes(handles.drum_axes);
%a = get(gca,'ButtonDownFcn');
h = imagesc(handles.input,'Parent',gca);
%set(h,'HitTest','off');
%set(gca,'ButtonDownFcn',a);
%set(h,'ButtonDownFcn',a);
set(handles.drum_axes,'visible','off');

i = imread('guitar_icon.png');
handles.input=im2double(i);
axes(handles.guitar_axes);
%a = get(gca,'ButtonDownFcn');
h = imagesc(handles.input,'Parent',gca);
%set(h,'HitTest','off');
%set(gca,'ButtonDownFcn',a);
%set(h,'ButtonDownFcn',a);
set(handles.guitar_axes,'visible','off');

i = imread('dmachine_icon.png');
handles.input=im2double(i);
axes(handles.dmachine_axes);
%a = get(gca,'ButtonDownFcn');
h = imagesc(handles.input,'Parent',gca);
%set(h,'HitTest','off');
%set(gca,'ButtonDownFcn',a);
%set(h,'ButtonDownFcn',a);
set(handles.dmachine_axes,'visible','off');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes menu wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = menu_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y
set(handles.lbl_x, 'string', ['x loc:' num2str(x)]); % update text for x loc
set(handles.lbl_y, 'string', ['y loc:' num2str(y)]); % update text for y loc 

drum = [577 344];
guitar = [204 141];
ddrum = sqrt( (c(1,2)-drum(1,2))^2 + (c(1,1)-drum(1,1))^2 );
dguitar = sqrt( (c(1,2)-guitar(1,2))^2 + (c(1,1)-guitar(1,1))^2 );

if ( x >= 125  && x <= 295 ) && ( y >= 283  && y <= 387 )
    set(handles.piano_panel,'visible','on')
elseif ddrum < 75
    set(handles.drum_panel,'visible','on')
elseif dguitar < 65
    set(handles.guitar_panel,'visible','on')
elseif ( x >= 500  && x <= 655 ) && ( y >= 78  && y <= 190 )
    set(handles.dmachine_panel,'visible','on')
else
    set(handles.piano_panel,'visible','off')
    set(handles.drum_panel,'visible','off')
    set(handles.guitar_panel,'visible','off')
    set(handles.dmachine_panel,'visible','off')
end


% --- Executes on mouse press over axes background.
function piano_axes_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to piano_axes (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
piano;