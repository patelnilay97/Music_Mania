function varargout = guitar(varargin)
% GUITAR MATLAB code for guitar.fig
%      GUITAR, by itself, creates a new GUITAR or raises the existing
%      singleton*.
%
%      H = GUITAR returns the handle to a new GUITAR or the handle to
%      the existing singleton*.
%
%      GUITAR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUITAR.M with the given input arguments.
%
%      GUITAR('Property','Value',...) creates a new GUITAR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before guitar_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to guitar_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help guitar

% Last Modified by GUIDE v2.5 12-Apr-2017 18:04:44

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @guitar_OpeningFcn, ...
                   'gui_OutputFcn',  @guitar_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before guitar is made visible.
function guitar_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to guitar (see VARARGIN)

% Choose default command line output for guitar
handles.output = hObject;

% create an axes that spans the whole gui
ah = axes('unit', 'normalized', 'position', [0 0 1 1]); 
% import the background image and show it on the axes
bg = imread('guitar.png');imagesc(bg);
% prevent plotting over the background and turn the axis off
set(ah,'handlevisibility','off','visible','off')
% making sure the background is behind all the other uicontrols
uistack(ah, 'bottom');

[handles.E1, handles.fs] = audioread('003_E1_PC_1.wav');
handles.B1 = audioread('010_B1_PC_1.wav');
handles.G1 = audioread('006_G1_PC_1.wav');
handles.D1 = audioread('001_D1_PC_1.wav');
handles.A1 = audioread('008_A1_PC_1.wav');
handles.E2 = audioread('015_E2_PC_1.wav');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes guitar wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = guitar_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on mouse motion over figure - except title and menu.
function figure1_WindowButtonMotionFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y
set(handles.lbl_x, 'string', ['x loc:' num2str(x)]); % update text for x loc
set(handles.lbl_y, 'string', ['y loc:' num2str(y)]); % update text for y loc 


if ( x >= 258  && x <= 315 ) && ( y >= 246  && y <= 250 )
    sound(handles.E1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 238  && y <= 242 )
    sound(handles.B1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 231  && y <= 235 )
    sound(handles.G1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 223  && y <= 227 )
    sound(handles.D1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 215  && y <= 219 )
    sound(handles.A1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 207  && y <= 211 )
    sound(handles.E2,handles.fs)
end


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function figure1_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
c = get(hObject, 'currentpoint'); % get mouse location on figure
x = c(1); y = c(2); % assign locations to x and y
set(handles.lbl_x, 'string', ['x loc:' num2str(x)]); % update text for x loc
set(handles.lbl_y, 'string', ['y loc:' num2str(y)]); % update text for y loc 


if ( x >= 258  && x <= 315 ) && ( y >= 246  && y <= 250 )
    sound(handles.E1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 238  && y <= 242 )
    sound(handles.B1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 231  && y <= 235 )
    sound(handles.G1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 223  && y <= 227 )
    sound(handles.D1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 215  && y <= 219 )
    sound(handles.A1,handles.fs)
elseif ( x >= 258  && x <= 315 ) && ( y >= 207  && y <= 211 )
    sound(handles.E2,handles.fs)
end